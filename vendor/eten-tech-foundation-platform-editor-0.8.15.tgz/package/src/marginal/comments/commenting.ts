/**
 * Adapted from https://github.com/facebook/lexical/blob/93cf85e12033b114ad347dcccf508c846a833731/packages/lexical-playground/src/commenting/index.ts
 */

import { Provider, TOGGLE_CONNECT_COMMAND } from "@lexical/yjs";
import { COMMAND_PRIORITY_LOW, LexicalEditor } from "lexical";
import { useEffect, useState } from "react";
import { Array as YArray, Map as YMap, Transaction, YArrayEvent, YEvent } from "yjs";
import { LoggerBasic } from "shared";

/**
 * Represents a single comment in a thread.
 *
 * @public
 */
export interface CommentBase {
  /** The author of the comment. */
  author: string;
  /** The content of the comment. */
  content: string;
  /** Whether the comment has been deleted. */
  deleted: boolean;
  /** Unique identifier for the comment. */
  id: string;
  /** Timestamp when the comment was created. */
  timeStamp: number;
  /** The type of this object, always "comment". */
  type: "comment";
}

/**
 * Represents a thread of comments, typically attached to a quote.
 *
 * @public
 */
export interface Thread {
  /** Array of comments in the thread. */
  comments: CommentBase[];
  /** Unique identifier for the thread. */
  id: string;
  /** The quoted text to which the thread is attached. */
  quote: string;
  /** The type of this object, always "thread". */
  type: "thread";
}

/**
 * Represents a list of comments and threads.
 *
 * @public
 */
export type Comments = (Thread | CommentBase)[];

function createUID(): string {
  return Math.random()
    .toString(36)
    .replace(/[^a-z]+/g, "")
    .substr(0, 5);
}

/**
 * Creates a new comment object.
 *
 * @param content - The content of the comment.
 * @param author - The author of the comment.
 * @param id - Optional unique identifier for the comment.
 * @param timeStamp - Optional timestamp for the comment.
 * @param deleted - Optional flag indicating if the comment is deleted.
 * @returns A new Comment object.
 */
export function createComment(
  content: string,
  author: string,
  id?: string,
  timeStamp?: number,
  deleted?: boolean,
): CommentBase {
  return {
    author,
    content,
    deleted: deleted === undefined ? false : deleted,
    id: id === undefined ? createUID() : id,
    timeStamp: timeStamp === undefined ? performance.timeOrigin + performance.now() : timeStamp,
    type: "comment",
  };
}

/**
 * Creates a new thread object.
 *
 * @param quote - The quoted text for the thread.
 * @param comments - Array of comments in the thread.
 * @param id - Optional unique identifier for the thread.
 * @returns A new Thread object.
 */
export function createThread(quote: string, comments: CommentBase[], id?: string): Thread {
  return {
    comments,
    id: id === undefined ? createUID() : id,
    quote,
    type: "thread",
  };
}

function cloneThread(thread: Thread): Thread {
  return {
    comments: Array.from(thread.comments),
    id: thread.id,
    quote: thread.quote,
    type: "thread",
  };
}

function markDeleted(comment: CommentBase): CommentBase {
  return {
    author: comment.author,
    content: "[Deleted Comment]",
    deleted: true,
    id: comment.id,
    timeStamp: comment.timeStamp,
    type: "comment",
  };
}

function triggerOnChange(commentStore: CommentStore): void {
  const listeners = commentStore._changeListeners;
  for (const listener of listeners) {
    listener();
  }
}

/**
 * Stores and manages comments and threads, including collaborative editing support.
 *
 * @typeParam TLogger - Logger type, defaults to LoggerBasic.
 */
export class CommentStore<TLogger extends LoggerBasic = LoggerBasic> {
  _editor: LexicalEditor;
  _comments: Comments;
  _changeListeners: Set<() => void>;
  _collabProvider: null | Provider;
  private logger: TLogger | undefined;

  /**
   * Creates a new CommentStore instance.
   *
   * @param editor - The LexicalEditor instance.
   * @param logger - Optional logger instance.
   */
  constructor(editor: LexicalEditor, logger?: TLogger) {
    this._comments = [];
    this._editor = editor;
    this.logger = logger;
    this._collabProvider = null;
    this._changeListeners = new Set();
  }

  /**
   * Checks if collaborative editing is enabled.
   *
   * @returns True if collaborative editing is enabled, false otherwise.
   */
  isCollaborative(): boolean {
    return this._collabProvider !== null;
  }

  /**
   * Gets the current list of comments and threads.
   *
   * @returns The Comments array.
   */
  getComments(): Comments {
    return this._comments;
  }

  /**
   * Sets the list of comments and threads.
   *
   * @param comments - The new Comments array.
   */
  setComments(comments: Comments) {
    this._comments = comments;
    triggerOnChange(this);
  }

  /**
   * Adds a comment or thread to the store.
   *
   * @param commentOrThread - The comment or thread to add.
   * @param thread - Optional parent thread to add the comment to.
   * @param offset - Optional offset for insertion.
   */
  addComment(commentOrThread: CommentBase | Thread, thread?: Thread, offset?: number): void {
    const nextComments = Array.from(this._comments);
    // The YJS types explicitly use `any` as well.
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const sharedCommentsArray: YArray<any> | null = this._getCollabComments();

    if (thread !== undefined && commentOrThread.type === "comment") {
      for (let i = 0; i < nextComments.length; i++) {
        const comment = nextComments[i];
        if (comment.type === "thread" && comment.id === thread.id) {
          const newThread = cloneThread(comment);
          nextComments.splice(i, 1, newThread);
          const insertOffset = offset !== undefined ? offset : newThread.comments.length;
          if (this.isCollaborative() && sharedCommentsArray !== null) {
            const parentSharedArray = sharedCommentsArray.get(i).get("comments");
            this._withRemoteTransaction(() => {
              const sharedMap = this._createCollabSharedMap(commentOrThread);
              parentSharedArray.insert(insertOffset, [sharedMap]);
            });
          }
          newThread.comments.splice(insertOffset, 0, commentOrThread);
          break;
        }
      }
    } else {
      const insertOffset = offset !== undefined ? offset : nextComments.length;
      if (this.isCollaborative() && sharedCommentsArray !== null) {
        this._withRemoteTransaction(() => {
          const sharedMap = this._createCollabSharedMap(commentOrThread);
          sharedCommentsArray.insert(insertOffset, [sharedMap]);
        });
      }
      nextComments.splice(insertOffset, 0, commentOrThread);
    }
    this._comments = nextComments;
    triggerOnChange(this);
  }

  /**
   * Deletes a comment or thread from the store.
   *
   * @param commentOrThread - The comment or thread to delete.
   * @param thread - Optional parent thread if deleting a comment within a thread.
   * @returns An object containing the marked comment and its index, or null.
   */
  deleteCommentOrThread(
    commentOrThread: CommentBase | Thread,
    thread?: Thread,
  ): { markedComment: CommentBase; index: number } | null {
    const nextComments = Array.from(this._comments);
    // The YJS types explicitly use `any` as well.
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const sharedCommentsArray: YArray<any> | null = this._getCollabComments();
    let commentIndex: number | null = null;

    if (thread !== undefined) {
      for (let i = 0; i < nextComments.length; i++) {
        const nextComment = nextComments[i];
        if (nextComment.type === "thread" && nextComment.id === thread.id) {
          const newThread = cloneThread(nextComment);
          nextComments.splice(i, 1, newThread);
          const threadComments = newThread.comments;
          commentIndex = threadComments.indexOf(commentOrThread as CommentBase);
          if (this.isCollaborative() && sharedCommentsArray !== null) {
            const parentSharedArray = sharedCommentsArray.get(i).get("comments");
            const deleteIndex = commentIndex;
            this._withRemoteTransaction(() => {
              parentSharedArray.delete(deleteIndex);
            });
          }
          threadComments.splice(commentIndex, 1);
          break;
        }
      }
    } else {
      commentIndex = nextComments.indexOf(commentOrThread);
      if (this.isCollaborative() && sharedCommentsArray !== null) {
        this._withRemoteTransaction(() => {
          sharedCommentsArray.delete(commentIndex as number);
        });
      }
      nextComments.splice(commentIndex, 1);
    }
    this._comments = nextComments;
    triggerOnChange(this);

    if (commentOrThread.type === "comment") {
      return {
        index: commentIndex as number,
        markedComment: markDeleted(commentOrThread as CommentBase),
      };
    }

    return null;
  }

  /**
   * Registers a callback to be called when the comments change.
   *
   * @param onChange - The callback function.
   * @returns A function to unregister the callback.
   */
  registerOnChange(onChange: () => void): () => void {
    const changeListeners = this._changeListeners;
    changeListeners.add(onChange);
    return () => {
      changeListeners.delete(onChange);
    };
  }

  _withRemoteTransaction(fn: () => void): void {
    const provider = this._collabProvider;
    if (provider !== null) {
      // @ts-expect-error doc does exist
      const doc = provider.doc;
      doc.transact(fn, this);
    }
  }

  _withLocalTransaction(fn: () => void): void {
    const collabProvider = this._collabProvider;
    try {
      this._collabProvider = null;
      fn();
    } finally {
      this._collabProvider = collabProvider;
    }
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  _getCollabComments(): null | YArray<any> {
    const provider = this._collabProvider;
    if (provider !== null) {
      // @ts-expect-error doc does exist
      const doc = provider.doc;
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      return doc.get("comments", YArray) as YArray<any>;
    }
    return null;
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  _createCollabSharedMap(commentOrThread: CommentBase | Thread): YMap<any> {
    const sharedMap = new YMap();
    const type = commentOrThread.type;
    const id = commentOrThread.id;
    sharedMap.set("type", type);
    sharedMap.set("id", id);
    if (type === "comment") {
      sharedMap.set("author", commentOrThread.author);
      sharedMap.set("content", commentOrThread.content);
      sharedMap.set("deleted", commentOrThread.deleted);
      sharedMap.set("timeStamp", commentOrThread.timeStamp);
    } else {
      sharedMap.set("quote", commentOrThread.quote);
      const commentsArray = new YArray();
      commentOrThread.comments.forEach((comment, i) => {
        const sharedChildComment = this._createCollabSharedMap(comment);
        commentsArray.insert(i, [sharedChildComment]);
      });
      sharedMap.set("comments", commentsArray);
    }
    return sharedMap;
  }

  /**
   * Registers collaborative editing support using a Yjs provider.
   *
   * @param provider - The Yjs Provider instance.
   * @returns A function to unregister collaboration and cleanup.
   */
  registerCollaboration(provider: Provider): () => void {
    this._collabProvider = provider;
    const sharedCommentsArray = this._getCollabComments();

    const connect = () => {
      provider.connect();
    };

    const disconnect = () => {
      try {
        provider.disconnect();
      } catch {
        // Do nothing
      }
    };

    const unsubscribe = this._editor.registerCommand(
      TOGGLE_CONNECT_COMMAND,
      (payload) => {
        if (connect !== undefined && disconnect !== undefined) {
          const shouldConnect = payload;

          if (shouldConnect) {
            this.logger?.info("Comments connected!");
            connect();
          } else {
            this.logger?.info("Comments disconnected!");
            disconnect();
          }
        }

        return false;
      },
      COMMAND_PRIORITY_LOW,
    );

    const onSharedCommentChanges = (
      // The YJS types explicitly use `any` as well.
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      events: YEvent<any>[],
      transaction: Transaction,
    ) => {
      if (transaction.origin !== this) {
        for (const event of events) {
          if (event instanceof YArrayEvent) {
            const target = event.target;
            const deltas = event.delta;
            let offset = 0;

            for (const delta of deltas) {
              const insert = delta.insert;
              const retain = delta.retain;
              const del = delta.delete;
              const parent = target.parent;
              const parentThread =
                target === sharedCommentsArray
                  ? undefined
                  : parent instanceof YMap &&
                    (this._comments.find((t) => t.id === parent.get("id")) as Thread | undefined);

              if (Array.isArray(insert)) {
                const addOffset = offset;
                insert
                  .slice()
                  .reverse()
                  // eslint-disable-next-line @typescript-eslint/no-explicit-any
                  .forEach((map: YMap<any>) => {
                    const id = map.get("id");
                    const type = map.get("type");

                    const commentOrThread =
                      type === "thread"
                        ? createThread(
                            map.get("quote"),
                            map
                              .get("comments")
                              .toArray()
                              .map((innerComment: Map<string, string | number | boolean>) =>
                                createComment(
                                  innerComment.get("content") as string,
                                  innerComment.get("author") as string,
                                  innerComment.get("id") as string,
                                  innerComment.get("timeStamp") as number,
                                  innerComment.get("deleted") as boolean,
                                ),
                              ),
                            id,
                          )
                        : createComment(
                            map.get("content"),
                            map.get("author"),
                            id,
                            map.get("timeStamp"),
                            map.get("deleted"),
                          );
                    this._withLocalTransaction(() => {
                      this.addComment(commentOrThread, parentThread as Thread, addOffset);
                    });
                  });
              } else if (typeof retain === "number") {
                offset += retain;
              } else if (typeof del === "number") {
                for (let d = 0; d < del; d++) {
                  const commentOrThread =
                    parentThread === undefined || parentThread === false
                      ? this._comments[offset]
                      : parentThread.comments[offset];
                  this._withLocalTransaction(() => {
                    this.deleteCommentOrThread(commentOrThread, parentThread as Thread);
                  });
                  offset++;
                }
              }
            }
          }
        }
      }
    };

    if (sharedCommentsArray === null) {
      return () => null;
    }

    sharedCommentsArray.observeDeep(onSharedCommentChanges);

    connect();

    return () => {
      sharedCommentsArray.unobserveDeep(onSharedCommentChanges);
      unsubscribe();
      this._collabProvider = null;
    };
  }
}

/**
 * React hook for subscribing to comment store changes.
 *
 * @param commentStore - The CommentStore instance.
 * @returns The current Comments array.
 */
export function useCommentStore(commentStore: CommentStore): Comments {
  const [comments, setComments] = useState<Comments>(commentStore.getComments());

  useEffect(() => {
    return commentStore.registerOnChange(() => {
      setComments(commentStore.getComments());
    });
  }, [commentStore]);

  return comments;
}
